$(document).ready(function(){
		console.log("doc is ready!");
		$("#panel-1").css({'background-image':'url("./img/madrid.JPG")','background-size': '300px 250px'});
		$("#panel-2").css({'background-image':'url("./img/beijing.JPG")','background-size':'300px 250px'});
		$("#panel-3").css({'background-image':'url("./img/ciudad_mexico.JPG")','background-size':'300px 250px'});
		$("#panel-4").css({'background-image':'url("./img/new_york.JPG")','background-size':'300px 250px'});
		$("#panel-5").css({'background-image':'url("./img/buenos_aires.JPG")','background-size':'300px 250px'});
		$("#panel-6").css({'background-image':'url("./img/tokyo.JPG")','background-size':'300px 250px'});
});
